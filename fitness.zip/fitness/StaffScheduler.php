<?php
// StaffScheduler.php - основная логика планирования

class StaffScheduler {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    /**
     * Получить требуемое количество персонала на основе прогноза
     */
    public function getRequiredStaffByHour($date) {
        $stmt = $this->pdo->prepare("
            SELECT hour_slot, predicted_visitors 
            FROM attendance_forecast 
            WHERE forecast_date = ?
        ");
        $stmt->execute([$date]);
        $forecast = $stmt->fetchAll();
        
        $required = ['trainer' => [], 'admin' => [], 'director' => []];
        
        foreach ($forecast as $row) {
            $visitors = $row['predicted_visitors'];
            $required['trainer'][$row['hour_slot']] = ceil($visitors / 15);
            $required['admin'][$row['hour_slot']] = max(1, ceil($visitors / 30));
            $required['director'][$row['hour_slot']] = ($row['hour_slot'] >= 10 && $row['hour_slot'] <= 18) ? 1 : 0;
        }
        
        return $required;
    }
    
    /**
     * Получить доступных сотрудников на определённое время
     */
    public function getAvailableStaff($role_name, $date, $start_time, $end_time) {
        $stmt = $this->pdo->prepare("
            SELECT s.* FROM staff s
            JOIN roles r ON s.role_id = r.id
            WHERE r.name = ? AND s.is_active = 1
            AND s.id NOT IN (
                SELECT staff_id FROM staff_shifts 
                WHERE shift_date = ? 
                AND NOT (end_time <= ? OR start_time >= ?)
            )
        ");
        $stmt->execute([$role_name, $date, $start_time, $end_time]);
        return $stmt->fetchAll();
    }
    
    /**
     * Назначить смену сотруднику
     */
    public function assignShift($staff_id, $date, $start_time, $end_time, $role_name, $created_by = null) {
        $stmt = $this->pdo->prepare("SELECT id FROM roles WHERE name = ?");
        $stmt->execute([$role_name]);
        $role_id = $stmt->fetchColumn();
        
        if (!$role_id) return false;
        
        $stmt = $this->pdo->prepare("
            INSERT INTO staff_shifts (staff_id, shift_date, start_time, end_time, role_id, created_by)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        return $stmt->execute([$staff_id, $date, $start_time, $end_time, $role_id, $created_by]);
    }
    
    /**
     * Автоматическое создание расписания на день
     */
    public function autoSchedule($date, $created_by = null) {
        $required = $this->getRequiredStaffByHour($date);
        
        // Часы работы клуба (6:00 - 23:00)
        for ($hour = 6; $hour <= 22; $hour++) {
            // 3-часовые смены
            $start = sprintf("%02d:00:00", $hour);
            $end = sprintf("%02d:00:00", min(23, $hour + 3));
            
            foreach (['trainer', 'admin', 'director'] as $role) {
                $need = $required[$role][$hour] ?? 0;
                if ($need <= 0) continue;
                
                $available = $this->getAvailableStaff($role, $date, $start, $end);
                $toAssign = array_slice($available, 0, $need);
                
                foreach ($toAssign as $staff) {
                    $this->assignShift($staff['id'], $date, $start, $end, $role, $created_by);
                }
            }
        }
        
        return true;
    }
    
    /**
     * Проверить перегрузки на дату
     */
    public function checkOverloads($date) {
        $stmt = $this->pdo->prepare("
            SELECT staff_id, SUM(TIMESTAMPDIFF(HOUR, start_time, end_time)) as total_hours
            FROM staff_shifts
            WHERE shift_date = ?
            GROUP BY staff_id
            HAVING total_hours > 8
        ");
        $stmt->execute([$date]);
        return $stmt->fetchAll();
    }
    
    /**
     * Получить смены на дату
     */
    public function getShiftsByDate($date) {
        $stmt = $this->pdo->prepare("
            SELECT s.full_name, r.name as role_name, ss.start_time, ss.end_time, ss.staff_id
            FROM staff_shifts ss
            JOIN staff s ON ss.staff_id = s.id
            JOIN roles r ON ss.role_id = r.id
            WHERE ss.shift_date = ?
            ORDER BY ss.start_time
        ");
        $stmt->execute([$date]);
        return $stmt->fetchAll();
    }
    
    /**
     * Получить смены конкретного сотрудника на дату
     */
    public function getStaffShifts($staff_id, $date) {
        $stmt = $this->pdo->prepare("
            SELECT start_time, end_time, r.name as role_name
            FROM staff_shifts ss
            JOIN roles r ON ss.role_id = r.id
            WHERE ss.staff_id = ? AND ss.shift_date = ?
            ORDER BY ss.start_time
        ");
        $stmt->execute([$staff_id, $date]);
        return $stmt->fetchAll();
    }
    public function getRecommendedStaff($date) {
    $stmt = $this->pdo->prepare("
        SELECT hour_slot, predicted_visitors 
        FROM attendance_forecast 
        WHERE forecast_date = ?
        ORDER BY hour_slot
    ");
    $stmt->execute([$date]);
    $forecast = $stmt->fetchAll();
    
    $recommendations = [];
    foreach ($forecast as $row) {
        $visitors = $row['predicted_visitors'];
        $recommendations[$row['hour_slot']] = [
            'visitors' => $visitors,
            'trainers_needed' => max(1, ceil($visitors / 10)),
            'admins_needed' => max(1, ceil($visitors / 30)),
            'director_needed' => (($row['hour_slot'] >= 10 && $row['hour_slot'] <= 13) || 
                                  ($row['hour_slot'] >= 17 && $row['hour_slot'] <= 19)) ? 1 : 0
        ];
    }
    
    return $recommendations;
}
};

/**
 * Получить рекомендованное количество персонала на день
 */

?>
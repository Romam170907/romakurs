<?php
 
function checkAuth() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }
}

function checkRole($allowed_roles = []) {
    checkAuth();
    if (!empty($allowed_roles) && !in_array($_SESSION['role'], $allowed_roles)) {
        die('Доступ запрещён. Ваша роль: ' . $_SESSION['role']);
    }
}

function getCurrentUser() {
    return [
        'id' => $_SESSION['user_id'] ?? null,
        'staff_id' => $_SESSION['staff_id'] ?? null,
        'name' => $_SESSION['full_name'] ?? null,
        'role' => $_SESSION['role'] ?? null
    ];
}
?>
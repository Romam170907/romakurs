<?php
// auto_schedule.php - автоматическое создание расписания на основе прогноза
require_once 'config.php';
require_once 'auth_middleware.php';
require_once 'StaffScheduler.php';

checkRole(['director']);

$user = getCurrentUser();
$scheduler = new StaffScheduler($pdo);
$date = $_GET['date'] ?? date('Y-m-d');

// Получаем прогноз
$stmt = $pdo->prepare("
    SELECT hour_slot, predicted_visitors 
    FROM attendance_forecast 
    WHERE forecast_date = ?
    ORDER BY hour_slot
");
$stmt->execute([$date]);
$forecast = $stmt->fetchAll();

if (count($forecast) == 0) {
    die("Нет прогноза на эту дату. Сначала сгенерируйте прогноз на странице просмотра.");
}

// Удаляем старые смены на эту дату
$delete = $pdo->prepare("DELETE FROM staff_shifts WHERE shift_date = ?");
$delete->execute([$date]);

$assigned = 0;

// Создаём смены на основе прогноза
foreach ($forecast as $row) {
    $visitors = $row['predicted_visitors'];
    $hour = $row['hour_slot'];
    
    $trainers_needed = max(1, ceil($visitors / 10));
    $admins_needed = max(1, ceil($visitors / 30));
    $director_needed = (($hour >= 10 && $hour <= 13) || ($hour >= 17 && $hour <= 19)) ? 1 : 0;
    
    // Назначаем тренеров
    $trainers = $scheduler->getAvailableStaff('trainer', $date, sprintf("%02d:00:00", $hour), sprintf("%02d:00:00", $hour+2));
    for ($i = 0; $i < min($trainers_needed, count($trainers)); $i++) {
        $scheduler->assignShift($trainers[$i]['id'], $date, sprintf("%02d:00:00", $hour), sprintf("%02d:00:00", $hour+2), 'trainer', $user['staff_id']);
        $assigned++;
    }
    
    // Назначаем администраторов
    $admins = $scheduler->getAvailableStaff('admin', $date, sprintf("%02d:00:00", $hour), sprintf("%02d:00:00", $hour+3));
    for ($i = 0; $i < min($admins_needed, count($admins)); $i++) {
        $scheduler->assignShift($admins[$i]['id'], $date, sprintf("%02d:00:00", $hour), sprintf("%02d:00:00", $hour+3), 'admin', $user['staff_id']);
        $assigned++;
    }
    
    // Назначаем директора
    if ($director_needed) {
        $directors = $scheduler->getAvailableStaff('director', $date, "10:00:00", "19:00:00");
        if (count($directors) > 0) {
            $scheduler->assignShift($directors[0]['id'], $date, "10:00:00", "19:00:00", 'director', $user['staff_id']);
            $assigned++;
        }
    }
}

// Перенаправляем обратно с сообщением
header("Location: view_forecast.php?date={$date}&success=1");
exit;
?>
<?php
// dashboard.php - главная панель управления
require_once 'config.php';
require_once 'auth_middleware.php';
require_once 'StaffScheduler.php';
require_once 'forecast_model.php';

checkAuth();

$user = getCurrentUser();
$role = $user['role'];
$scheduler = new StaffScheduler($pdo);
$today = date('Y-m-d');

// Обработка действий
$action = $_GET['action'] ?? '';
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($action === 'auto_schedule' && $role === 'director') {
        $date = $_POST['date'] ?? $today;
        generateForecast($pdo, $date, 120);
        $scheduler->autoSchedule($date, $user['staff_id']);
        $message = "Расписание на {$date} успешно создано!";
    }
    
    if ($action === 'generate_forecast' && $role === 'director') {
        $date = $_POST['date'] ?? $today;
        $base = (int)($_POST['base_visitors'] ?? 120);
        generateForecast($pdo, $date, $base);
        $message = "Прогноз на {$date} сгенерирован!";
    }
}

// Получаем данные для отображения
$shifts = $scheduler->getShiftsByDate($today);
$overloads = $scheduler->checkOverloads($today);
$myShifts = ($role === 'trainer') ? $scheduler->getStaffShifts($user['staff_id'], $today) : [];

// Получаем всех тренеров для админа
$trainers = [];
if ($role === 'admin') {
    $stmt = $pdo->query("SELECT id, full_name FROM staff WHERE role_id = 1 AND is_active = 1");
    $trainers = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Панель управления - <?= ucfirst($role) ?></title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="header">
        <h1>Fitness Schedule</h1>
        <div class="user-info">
            <span> <?= htmlspecialchars($user['name']) ?></span>
            <span class="role-badge role-<?= $role ?>"><?= ucfirst($role) ?></span>
            <a href="logout.php" class="logout-btn">Выйти</a>
        </div>
    </div>
    
    <div class="container">
        <?php if ($message): ?>
            <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <!-- ========== ДИРЕКТОР ========== -->
        <?php if ($role === 'director'): ?>
            <div class="card">
                <h2>Управление расписанием</h2>
                <form method="POST" action="?action=auto_schedule" class="form-row">
                    <div class="form-group">
                        <label>Дата</label>
                        <input type="date" name="date" value="<?= $today ?>">
                    </div>
                    <button type="submit" class="btn">Создать авторасписание</button>
                </form>
            </div>
            
            <div class="card">
                <h2>Генерация прогноза посещаемости</h2>
                <form method="POST" action="?action=generate_forecast" class="form-row">
                    <div class="form-group">
                        <label>Дата</label>
                        <input type="date" name="date" value="<?= $today ?>">
                    </div>
                    <div class="form-group">
                        <label>Базовое кол-во посетителей</label>
                        <input type="number" name="base_visitors" value="120" step="10">
                    </div>
                    <button type="submit" class="btn">Сгенерировать прогноз</button>
                </form>
            </div>
            
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-number"><?= count($shifts) ?></div>
                    <div class="stat-label">Всего смен сегодня</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?= count($overloads) ?></div>
                    <div class="stat-label">Сотрудников с перегрузкой</div>
                </div>
            </div>
            
            <?php if (count($overloads) > 0): ?>
                <div class="alert alert-warning">
                    <strong>Внимание!</strong> Найдены перегрузки на сегодня:
                    <ul class="list">
                        <?php foreach ($overloads as $o): 
                            $stmt = $pdo->prepare("SELECT full_name FROM staff WHERE id = ?");
                            $stmt->execute([$o['staff_id']]);
                            $name = $stmt->fetchColumn();
                        ?>
                            <li><?= htmlspecialchars($name) ?> — <?= $o['total_hours'] ?> часов (норма 8)</li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <h2>Все смены на сегодня</h2>
                <?php $shiftsForTable = $shifts; include 'partials/shifts_table.php'; ?>
            </div>

            <div class="card">
                <h2>Управление сотрудниками</h2>
                <div class="actions">
                    <a href="register.php" class="btn">Добавить нового сотрудника</a>
                    <a href="staff_list.php" class="btn btn-secondary">Список всех сотрудников</a>
                    <a href="change_password.php" class="btn btn-secondary">Сменить пароль</a>
                    <a href="view_forecast.php" class="btn btn-secondary">Прогноз и расчёт персонала</a>
                </div>
</div>
        
        <!-- ========== АДМИНИСТРАТОР ========== -->
        <?php elseif ($role === 'admin'): ?>
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-number"><?= count($shifts) ?></div>
                    <div class="stat-label">Смен сегодня</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?= count($trainers) ?></div>
                    <div class="stat-label">Активных тренеров</div>
                </div>
            </div>
            
            <div class="card">
                <h2>Расписание всех сотрудников</h2>
                <?php $shiftsForTable = $shifts; include 'partials/shifts_table.php'; ?>
            </div>
            
            <div class="card">
                <h2>Записать клиента к тренеру</h2>
                <form class="form-row" onsubmit="alert('Демо: запись клиента добавлена'); return false;">
                    <div class="form-group">
                        <label>Имя клиента</label>
                        <input type="text" placeholder="Иван Петров" required>
                    </div>
                    <div class="form-group">
                        <label>Тренер</label>
                        <select required>
                            <option value="">Выберите тренера</option>
                            <?php foreach ($trainers as $trainer): ?>
                                <option><?= htmlspecialchars($trainer['full_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Время</label>
                        <input type="time" value="10:00">
                    </div>
                    <button type="submit" class="btn">Записать</button>
                </form>
            </div>
            <div class="mb-16">
                <a href="view_forecast.php" class="btn btn-secondary">Прогноз и расчёт персонала</a>
            </div>
        <!-- ========== ТРЕНЕР ========== -->
        <?php elseif ($role === 'trainer'): ?>
            <div class="card">
                <h2>Моё расписание на сегодня</h2>
                <?php if (count($myShifts) > 0): ?>
                    <ul class="schedule-list">
                        <?php foreach ($myShifts as $shift): ?>
                            <li>
                                <span class="time"><?= substr($shift['start_time'], 0, 5) ?> - <?= substr($shift['end_time'], 0, 5) ?></span>
                                — <?= $shift['role_name'] === 'trainer' ? 'Тренировка' : ($shift['role_name'] === 'admin' ? 'Администрирование' : 'Управление') ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p class="muted text-center p-20">У вас нет смен на сегодня.</p>
                <?php endif; ?>
            </div>
            
            <div class="card">
                <h2>Мои клиенты на сегодня</h2>
                <ul class="schedule-list">
                    <li><span class="time">10:00</span> — Иван Петров (персональная тренировка)</li>
                    <li><span class="time">12:00</span> — Елена Сидорова (групповое занятие)</li>
                    <li><span class="time">15:30</span> — Михаил Смирнов (персональная тренировка)</li>
                    <li><span class="time">18:00</span> — Ольга Кузнецова (групповое занятие)</li>
                </ul>
            </div>
            
            <div class="card">
                <h2>Моя статистика (неделя)</h2>
                <ul class="schedule-list">
                    <li>Всего тренировок: 12</li>
                    <li>Клиентов: 8</li>
                    <li>Средний рейтинг: 4.8</li>
                </ul>
            </div>
            <div class="mb-16">
                <a href="view_forecast.php" class="btn btn-secondary">Прогноз и расчёт персонала</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
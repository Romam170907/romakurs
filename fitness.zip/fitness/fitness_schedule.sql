-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3307
-- Время создания: Июн 29 2026 г., 00:26
-- Версия сервера: 8.0.30
-- Версия PHP: 8.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `fitness_schedule`
--

-- --------------------------------------------------------

--
-- Структура таблицы `attendance_forecast`
--

CREATE TABLE `attendance_forecast` (
  `id` int NOT NULL,
  `forecast_date` date NOT NULL,
  `hour_slot` tinyint NOT NULL COMMENT '0-23 час',
  `predicted_visitors` int NOT NULL,
  `source` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'simple_model'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `attendance_forecast`
--

INSERT INTO `attendance_forecast` (`id`, `forecast_date`, `hour_slot`, `predicted_visitors`, `source`) VALUES
(1, '2026-06-28', 8, 57, 'manual'),
(2, '2026-06-28', 9, 108, 'manual'),
(3, '2026-06-28', 10, 113, 'manual'),
(4, '2026-06-28', 11, 119, 'manual'),
(5, '2026-06-28', 17, 108, 'manual'),
(6, '2026-06-28', 18, 103, 'manual'),
(7, '2026-06-28', 19, 97, 'manual'),
(8, '2026-06-28', 20, 92, 'manual'),
(9, '2026-06-28', 6, 51, 'manual'),
(10, '2026-06-28', 7, 54, 'manual'),
(15, '2026-06-28', 12, 69, 'manual'),
(16, '2026-06-28', 13, 72, 'manual'),
(17, '2026-06-28', 14, 69, 'manual'),
(18, '2026-06-28', 15, 66, 'manual'),
(19, '2026-06-28', 16, 63, 'manual'),
(24, '2026-06-28', 21, 48, 'manual'),
(25, '2026-06-28', 22, 45, 'manual'),
(26, '2026-06-28', 23, 42, 'manual');

-- --------------------------------------------------------

--
-- Структура таблицы `club_hours`
--

CREATE TABLE `club_hours` (
  `id` int NOT NULL,
  `day_of_week` tinyint NOT NULL COMMENT '0=вс,1=пн,...,6=сб',
  `start_time` time NOT NULL,
  `end_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `club_hours`
--

INSERT INTO `club_hours` (`id`, `day_of_week`, `start_time`, `end_time`) VALUES
(1, 1, '06:00:00', '23:00:00'),
(2, 2, '06:00:00', '23:00:00'),
(3, 3, '06:00:00', '23:00:00'),
(4, 4, '06:00:00', '23:00:00'),
(5, 5, '06:00:00', '23:00:00'),
(6, 6, '08:00:00', '22:00:00'),
(7, 0, '08:00:00', '20:00:00');

-- --------------------------------------------------------

--
-- Структура таблицы `roles`
--

CREATE TABLE `roles` (
  `id` int NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'trainer, admin, director',
  `priority` int DEFAULT '0' COMMENT 'чем больше, тем выше доступ'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `roles`
--

INSERT INTO `roles` (`id`, `name`, `priority`) VALUES
(1, 'trainer', 10),
(2, 'admin', 20),
(3, 'director', 100);

-- --------------------------------------------------------

--
-- Структура таблицы `shift_templates`
--

CREATE TABLE `shift_templates` (
  `id` int NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_id` int NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `min_staff` int DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `shift_templates`
--

INSERT INTO `shift_templates` (`id`, `name`, `role_id`, `start_time`, `end_time`, `min_staff`) VALUES
(1, 'Утренняя', 1, '08:00:00', '11:00:00', 2),
(2, 'Дневная', 1, '12:00:00', '15:00:00', 2),
(3, 'Вечерняя', 1, '17:00:00', '20:00:00', 2),
(4, 'Админ утро', 2, '08:00:00', '14:00:00', 1),
(5, 'Админ вечер', 2, '14:00:00', '21:00:00', 1),
(6, 'Директор', 3, '10:00:00', '19:00:00', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `staff`
--

CREATE TABLE `staff` (
  `id` int NOT NULL,
  `full_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` int NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `max_hours_per_day` int DEFAULT '8',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `staff`
--

INSERT INTO `staff` (`id`, `full_name`, `role_id`, `phone`, `email`, `max_hours_per_day`, `is_active`, `created_at`) VALUES
(1, 'Роман тренер', 1, '+7-999-111-22-33', 'trainer@fitness.ru', 8, 1, '2026-06-28 09:51:53'),
(2, 'Тимур админ', 2, '+7-999-444-55-66', 'admin@fitness.ru', 8, 1, '2026-06-28 09:51:53'),
(3, 'Роман директор', 3, '+7-999-777-88-99', 'director@fitness.ru', 8, 1, '2026-06-28 09:51:53'),
(4, 'Виктория тренер', 1, '+7-999-222-33-44', 'elena@fitness.ru', 8, 1, '2026-06-28 09:51:53'),
(5, 'Сергей тренер', 1, '+7-999-555-66-77', 'sergey@fitness.ru', 8, 1, '2026-06-28 09:51:53');

-- --------------------------------------------------------

--
-- Структура таблицы `staff_load`
--

CREATE TABLE `staff_load` (
  `id` int NOT NULL,
  `staff_id` int NOT NULL,
  `load_date` date NOT NULL,
  `total_hours` decimal(5,2) DEFAULT NULL,
  `is_overloaded` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `staff_shifts`
--

CREATE TABLE `staff_shifts` (
  `id` int NOT NULL,
  `staff_id` int NOT NULL,
  `shift_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `role_id` int NOT NULL COMMENT 'дублируем для быстрых фильтров',
  `created_by` int DEFAULT NULL COMMENT 'кто назначил (ID персонала)',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `staff_id` int NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'пароль в открытом виде',
  `last_login` datetime DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `staff_id`, `username`, `password`, `last_login`, `is_active`, `created_at`) VALUES
(1, 1, 'trainer', '123456', '2026-06-28 12:52:26', 1, '2026-06-28 09:51:53'),
(2, 2, 'admin', '123456', '2026-06-28 12:58:12', 1, '2026-06-28 09:51:53'),
(3, 3, 'director', '123456', NULL, 1, '2026-06-28 09:51:53');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `attendance_forecast`
--
ALTER TABLE `attendance_forecast`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_forecast` (`forecast_date`,`hour_slot`);

--
-- Индексы таблицы `club_hours`
--
ALTER TABLE `club_hours`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Индексы таблицы `shift_templates`
--
ALTER TABLE `shift_templates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role_id` (`role_id`);

--
-- Индексы таблицы `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role_id` (`role_id`);

--
-- Индексы таблицы `staff_load`
--
ALTER TABLE `staff_load`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `staff_id` (`staff_id`,`load_date`);

--
-- Индексы таблицы `staff_shifts`
--
ALTER TABLE `staff_shifts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `staff_id` (`staff_id`),
  ADD KEY `role_id` (`role_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `staff_id` (`staff_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `attendance_forecast`
--
ALTER TABLE `attendance_forecast`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT для таблицы `club_hours`
--
ALTER TABLE `club_hours`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `shift_templates`
--
ALTER TABLE `shift_templates`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `staff_load`
--
ALTER TABLE `staff_load`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `staff_shifts`
--
ALTER TABLE `staff_shifts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `shift_templates`
--
ALTER TABLE `shift_templates`
  ADD CONSTRAINT `shift_templates_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);

--
-- Ограничения внешнего ключа таблицы `staff`
--
ALTER TABLE `staff`
  ADD CONSTRAINT `staff_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE RESTRICT;

--
-- Ограничения внешнего ключа таблицы `staff_load`
--
ALTER TABLE `staff_load`
  ADD CONSTRAINT `staff_load_ibfk_1` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`);

--
-- Ограничения внешнего ключа таблицы `staff_shifts`
--
ALTER TABLE `staff_shifts`
  ADD CONSTRAINT `staff_shifts_ibfk_1` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`),
  ADD CONSTRAINT `staff_shifts_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);

--
-- Ограничения внешнего ключа таблицы `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

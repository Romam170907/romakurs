<?php
// forecast_model.php - генерация прогноза посещаемости

function generateForecast($pdo, $date, $base_visitors = 120) {
    $dayOfWeek = date('w', strtotime($date));
    $weekendFactor = ($dayOfWeek == 0 || $dayOfWeek == 6) ? 0.6 : 1.2;
    
    for ($hour = 6; $hour <= 22; $hour++) {
        // Пиковые часы
        $isPeak = ($hour >= 9 && $hour <= 11) || ($hour >= 17 && $hour <= 20);
        $peakFactor = $isPeak ? 1.8 : 1.0;
        
        $visitors = round($base_visitors * $peakFactor * $weekendFactor * (1 - abs($hour - 13) / 24));
        $visitors = max(5, $visitors);
        
        $stmt = $pdo->prepare("
            INSERT INTO attendance_forecast (forecast_date, hour_slot, predicted_visitors, source)
            VALUES (?, ?, ?, 'manual')
            ON DUPLICATE KEY UPDATE predicted_visitors = VALUES(predicted_visitors)
        ");
        $stmt->execute([$date, $hour, $visitors]);
    }
    
    return true;
}
?>
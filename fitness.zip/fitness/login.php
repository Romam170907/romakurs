<?php
// login.php - страница входа (пароль без хэширования)
require_once 'config.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $selectedRole = $_POST['role'] ?? '';
    
    // Прямое сравнение пароля без хэширования
    $stmt = $pdo->prepare("
        SELECT u.*, s.full_name, r.name as role_name
        FROM users u
        JOIN staff s ON u.staff_id = s.id
        JOIN roles r ON s.role_id = r.id
        WHERE u.username = ? AND u.password = ? AND u.is_active = 1
    ");
    $stmt->execute([$username, $password]);
    $user = $stmt->fetch();
    
    if ($user) {
        if ($user['role_name'] !== $selectedRole) {
            $error = "Ошибка: Вы выбрали роль '{$selectedRole}', но ваша реальная роль '{$user['role_name']}'!";
        } else {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['staff_id'] = $user['staff_id'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['role'] = $user['role_name'];
            
            // Обновляем время последнего входа
            $update = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
            $update->execute([$user['id']]);
            
            header('Location: dashboard.php');
            exit;
        }
    } else {
        $error = 'Неверный логин или пароль';
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Вход - Фитнес клуб</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body class="auth">
    <div class="login-container">
        <h2>Fitness Schedule</h2>
        <div class="subtitle">Планирование загрузки персонала</div>
        
        <?php if ($error): ?>
            <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label>Логин</label>
                <input type="text" name="username" required placeholder="">
            </div>
            
            <div class="form-group">
                <label>Пароль</label>
                <input type="password" name="password" required placeholder="">
            </div>
            
            <div class="form-group">
                <label>Войти как</label>
                <select name="role" required>
                    <option value=""> Выберите роль</option>
                    <option value="trainer">Тренер</option>
                    <option value="admin">Администратор</option>
                    <option value="director">Директор</option>
                </select>
            </div>
            
            <button type="submit" class="btn btn-block">Войти в систему</button>
        </form>
        
       
    </div>
</body>
</html>

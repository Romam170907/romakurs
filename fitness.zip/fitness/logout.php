<?php
// logout.php - выход из системы
session_start();
session_destroy();
header('Location: login.php');
exit;
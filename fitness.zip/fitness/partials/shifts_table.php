<?php
// partials/shifts_table.php - таблица смен
if (!isset($shifts)) {
    $shifts = [];
}
?>

<?php if (count($shifts) > 0): ?>
    <div class="table-wrap">
    <table class="table">
        <thead>
            <tr>
                <th>Сотрудник</th>
                <th>Роль</th>
                <th>Начало</th>
                <th>Конец</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($shifts as $shift): ?>
            <tr>
                <td><?= htmlspecialchars($shift['full_name']) ?></td>
                <td><?= htmlspecialchars($shift['role_name']) ?></td>
                <td><?= substr($shift['start_time'], 0, 5) ?></td>
                <td><?= substr($shift['end_time'], 0, 5) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    </div>
<?php else: ?>
    <p class="muted text-center p-20">На сегодня смен не назначено</p>
<?php endif; ?>
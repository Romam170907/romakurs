<?php
// register.php - регистрация новых пользователей (только директор)
// Пароль без хэширования
require_once 'config.php';
require_once 'auth_middleware.php';

// Только директор может создавать новых пользователей
checkRole(['director']);

$user = getCurrentUser();
$error = '';
$success = '';

// Получаем список ролей для выбора
$roles = $pdo->query("SELECT * FROM roles ORDER BY priority")->fetchAll();

// Обработка формы регистрации
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $role_id = (int)($_POST['role_id'] ?? 0);
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // Валидация
    if (empty($full_name)) {
        $error = 'Введите ФИО сотрудника';
    } elseif (empty($username)) {
        $error = 'Введите логин';
    } elseif (strlen($password) < 4) {
        $error = 'Пароль должен быть минимум 4 символа';
    } elseif ($password !== $confirm_password) {
        $error = 'Пароли не совпадают';
    } elseif ($role_id <= 0) {
        $error = 'Выберите роль';
    } else {
        try {
            $pdo->beginTransaction();
            
            // Проверка уникальности логина
            $check = $pdo->prepare("SELECT id FROM users WHERE username = ?");
            $check->execute([$username]);
            if ($check->fetch()) {
                throw new Exception('Пользователь с таким логином уже существует');
            }
            
            // Добавляем в таблицу staff
            $stmt = $pdo->prepare("
                INSERT INTO staff (full_name, role_id, phone, email, is_active) 
                VALUES (?, ?, ?, ?, 1)
            ");
            $stmt->execute([$full_name, $role_id, $phone, $email]);
            $staff_id = $pdo->lastInsertId();
            
            // Добавляем в таблицу users (пароль без хэширования)
            $stmt = $pdo->prepare("
                INSERT INTO users (staff_id, username, password, created_by) 
                VALUES (?, ?, ?, ?)
            ");
            $stmt->execute([$staff_id, $username, $password, $user['staff_id']]);
            
            $pdo->commit();
            $success = "Сотрудник '{$full_name}' успешно создан! Логин: {$username}, пароль: {$password}";
            
            // Очищаем форму
            $_POST = [];
            
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Регистрация сотрудника</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container container--narrow">
        <div class="header">
            <h2>Регистрация нового сотрудника</h2>
            <a href="dashboard.php">На главную</a>
        </div>
        <div class="card">
            <?php if ($success): ?>
                <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            
            <div class="alert alert-info">
                Создавая сотрудника, вы автоматически создаёте ему доступ в систему.
                Пароль сохраняется в открытом виде (для учебных целей).
            </div>
            
            <form method="POST">
                <div class="form-group">
                    <label>ФИО сотрудника *</label>
                    <input type="text" name="full_name" required value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>">
                </div>
                
                <div class="form-group">
                    <label>Телефон</label>
                    <input type="text" name="phone" value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">
                </div>
                
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                </div>
                
                <div class="form-group">
                    <label>Роль *</label>
                    <select name="role_id" required>
                        <option value="">-- Выберите роль --</option>
                        <?php foreach ($roles as $role): ?>
                            <option value="<?= $role['id'] ?>" <?= (($_POST['role_id'] ?? '') == $role['id']) ? 'selected' : '' ?>>
                                <?= ucfirst($role['name']) ?> (приоритет: <?= $role['priority'] ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <hr>
                
                <h2>Данные для входа</h2>
                
                <div class="form-group">
                    <label>Логин *</label>
                    <input type="text" name="username" required value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Пароль * (мин. 4 символа)</label>
                        <input type="password" name="password" required>
                    </div>
                    <div class="form-group">
                        <label>Подтверждение пароля *</label>
                        <input type="password" name="confirm_password" required>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-block">Создать сотрудника</button>
            </form>
            
            <a href="dashboard.php" class="back-link">Вернуться в панель управления</a>
        </div>
    </div>
</body>
</html>

<?php
// staff_list.php - управление сотрудниками (только директор)
require_once 'config.php';
require_once 'auth_middleware.php';

checkRole(['director']);

$user = getCurrentUser();

// Обработка действий
$action = $_GET['action'] ?? '';
$staff_id = (int)($_GET['id'] ?? 0);

if ($action === 'delete' && $staff_id) {
    // Не даём удалить самого себя
    if ($staff_id != $user['staff_id']) {
        $stmt = $pdo->prepare("UPDATE staff SET is_active = 0 WHERE id = ?");
        $stmt->execute([$staff_id]);
        $success = "Сотрудник деактивирован";
    } else {
        $error = "Нельзя деактивировать самого себя";
    }
}

if ($action === 'activate' && $staff_id) {
    $stmt = $pdo->prepare("UPDATE staff SET is_active = 1 WHERE id = ?");
    $stmt->execute([$staff_id]);
    $success = "Сотрудник активирован";
}

// Получаем список всех сотрудников
$staff_list = $pdo->query("
    SELECT s.*, r.name as role_name, u.username, u.last_login
    FROM staff s
    JOIN roles r ON s.role_id = r.id
    LEFT JOIN users u ON s.id = u.staff_id
    ORDER BY r.priority DESC, s.full_name
")->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Список сотрудников</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>Управление сотрудниками</h2>
            <a href="dashboard.php">На главную</a>
        </div>
        <div class="card">
            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
            <?php endif; ?>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            
            <div class="mb-16">
                <a href="register.php" class="btn">Добавить сотрудника</a>
            </div>
            
            <div class="table-wrap">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>ФИО</th>
                        <th>Роль</th>
                        <th>Телефон</th>
                        <th>Email</th>
                        <th>Логин</th>
                        <th>Последний вход</th>
                        <th>Статус</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($staff_list as $staff): ?>
                    <tr>
                        <td><?= $staff['id'] ?></td>
                        <td><?= htmlspecialchars($staff['full_name']) ?></td>
                        <td><?= htmlspecialchars($staff['role_name']) ?></td>
                        <td><?= htmlspecialchars($staff['phone'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($staff['email'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($staff['username'] ?? '-') ?></td>
                        <td><?= $staff['last_login'] ? date('d.m.Y H:i', strtotime($staff['last_login'])) : 'Никогда' ?></td>
                        <td class="<?= $staff['is_active'] ? 'status-active' : 'status-inactive' ?>">
                            <?= $staff['is_active'] ? 'Активен' : 'Деактивирован' ?>
                        </td>
                        <td>
                            <?php if ($staff['is_active']): ?>
                                <a href="?action=delete&id=<?= $staff['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Деактивировать сотрудника? Он не сможет войти в систему')">Деактивировать</a>
                            <?php else: ?>
                                <a href="?action=activate&id=<?= $staff['id'] ?>" class="btn btn-sm" onclick="return confirm('Активировать сотрудника?')">Активировать</a>
                            <?php endif; ?>
                            <a href="reset_password.php?id=<?= $staff['id'] ?>" class="btn btn-secondary btn-sm">Сбросить пароль</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            </div>
        </div>
    </div>
</body>
</html>
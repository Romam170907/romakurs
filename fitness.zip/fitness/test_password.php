<?php
// test_password.php - проверка паролей
require_once 'config.php';

$test_username = 'director';
$test_password = '123456';

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Проверка пароля</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container container--narrow">
        <div class="header">
            <h2>Проверка пароля</h2>
            <a href="login.php">К входу</a>
        </div>
        <div class="card">
            <h2>Пользователь: <?= htmlspecialchars($test_username) ?></h2>
<?php

$stmt = $pdo->prepare("
    SELECT u.*, s.full_name 
    FROM users u 
    JOIN staff s ON u.staff_id = s.id 
    WHERE u.username = ?
");
$stmt->execute([$test_username]);
$user = $stmt->fetch();

if ($user) {
    echo "<div class=\"alert alert-success\">Пользователь найден: " . htmlspecialchars($user['full_name']) . "</div>";
    echo "<div class=\"alert alert-info\"><strong>Хеш в БД:</strong><br>" . htmlspecialchars($user['password_hash']) . "</div>";
    
    if (password_verify($test_password, $user['password_hash'])) {
        echo "<div class=\"alert alert-success\">Пароль верный.</div>";
    } else {
        echo "<div class=\"alert alert-error\">Пароль неверный. Создаю новый правильный хеш.</div>";
        
        $new_hash = password_hash($test_password, PASSWORD_DEFAULT);
        $update = $pdo->prepare("UPDATE users SET password_hash = ? WHERE username = ?");
        $update->execute([$new_hash, $test_username]);
        
        echo "<div class=\"alert alert-success\">Пароль для {$test_username} обновлён на: {$test_password}</div>";
        echo "<div class=\"alert alert-info\"><strong>Новый хеш:</strong><br>" . htmlspecialchars($new_hash) . "</div>";
    }
} else {
    echo "<div class=\"alert alert-error\">Пользователь {$test_username} не найден.</div>";
}

echo "<hr>";
echo "<a href='login.php' class='btn btn-secondary'>Перейти к входу</a>";
?>
        </div>
    </div>
</body>
</html>
<?php
// view_forecast.php - просмотр прогноза и расчёт персонала
require_once 'config.php';
require_once 'auth_middleware.php';

checkAuth();

$user = getCurrentUser();
$selected_date = $_GET['date'] ?? date('Y-m-d');
$error = '';
$success = '';

// Генерация прогноза на дату
if (isset($_GET['generate'])) {
    $base_visitors = (int)($_GET['base_visitors'] ?? 120);
    
    // Простая формула прогноза
    $dayOfWeek = date('w', strtotime($selected_date));
    $weekendFactor = ($dayOfWeek == 0 || $dayOfWeek == 6) ? 0.6 : 1.2;
    
    for ($hour = 6; $hour <= 23; $hour++) {
        $isPeak = ($hour >= 9 && $hour <= 11) || ($hour >= 17 && $hour <= 20);
        $peakFactor = $isPeak ? 1.8 : 1.0;
        
        $visitors = round($base_visitors * $peakFactor * $weekendFactor * (1 - abs($hour - 13) / 24));
        $visitors = max(3, $visitors);
        
        $stmt = $pdo->prepare("
            INSERT INTO attendance_forecast (forecast_date, hour_slot, predicted_visitors, source)
            VALUES (?, ?, ?, 'manual')
            ON DUPLICATE KEY UPDATE predicted_visitors = VALUES(predicted_visitors), source = 'manual'
        ");
        $stmt->execute([$selected_date, $hour, $visitors]);
    }
    
    $success = "Прогноз на {$selected_date} успешно сгенерирован!";
}

// Получаем прогноз из БД
$stmt = $pdo->prepare("
    SELECT hour_slot, predicted_visitors, source 
    FROM attendance_forecast 
    WHERE forecast_date = ?
    ORDER BY hour_slot
");
$stmt->execute([$selected_date]);
$forecast = $stmt->fetchAll();

// Если прогноза нет, показываем заглушку
$has_forecast = count($forecast) > 0;

// Расчёт необходимого персонала
$staff_requirements = [];
$total_visitors_day = 0;

if ($has_forecast) {
    foreach ($forecast as $row) {
        $visitors = $row['predicted_visitors'];
        $total_visitors_day += $visitors;
        
        // Формулы расчёта персонала
        // 1 тренер на 10 человек (для качественных тренировок)
        // 1 администратор на 30 человек
        $trainers_needed = max(1, ceil($visitors / 10));
        $admins_needed = max(1, ceil($visitors / 30));
        
        // Директор только в пиковые часы
        $director_needed = 0;
        if (($row['hour_slot'] >= 10 && $row['hour_slot'] <= 13) || 
            ($row['hour_slot'] >= 17 && $row['hour_slot'] <= 19)) {
            $director_needed = 1;
        }
        
        $staff_requirements[$row['hour_slot']] = [
            'visitors' => $visitors,
            'trainers' => $trainers_needed,
            'admins' => $admins_needed,
            'director' => $director_needed,
            'total_staff' => $trainers_needed + $admins_needed + $director_needed
        ];
    }
}

// Получаем реальные смены на эту дату для сравнения
$actual_shifts = [];
if ($has_forecast) {
    $actual_shifts_stmt = $pdo->prepare("
        SELECT r.name as role, COUNT(*) as count, 
               HOUR(start_time) as hour_slot
        FROM staff_shifts ss
        JOIN roles r ON ss.role_id = r.id
        WHERE ss.shift_date = ?
        GROUP BY r.name, HOUR(start_time)
    ");
    $actual_shifts_stmt->execute([$selected_date]);
    $actual_data = $actual_shifts_stmt->fetchAll();
    
    foreach ($actual_data as $shift) {
        $actual_shifts[$shift['hour_slot']][$shift['role']] = $shift['count'];
    }
}

// Рекомендации по пиковым часам
$peak_hours = [];
foreach ($staff_requirements as $hour => $req) {
    if ($req['visitors'] > 50) {
        $peak_hours[] = $hour;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Прогноз посещаемости и расчёт персонала</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container container--wide">
        <div class="header">
            <h2>Прогноз посещаемости и расчёт персонала</h2>
            <a href="dashboard.php">На главную</a>
        </div>
        
        <div class="card">
            <h2>Выбор даты</h2>
            <form method="GET" class="form-row">
                <div class="form-group">
                    <label>Дата</label>
                    <input type="date" name="date" value="<?= $selected_date ?>">
                </div>
                <button type="submit" class="btn">Показать прогноз</button>
                <a href="?date=<?= $selected_date ?>&generate=1&base_visitors=120" class="btn btn-secondary">Сгенерировать прогноз</a>
                <a href="auto_schedule.php?date=<?= $selected_date ?>" class="btn btn-secondary">Создать расписание по прогнозу</a>
            </form>
        </div>
        
        <?php if ($success): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>
        
        <?php if (!$has_forecast): ?>
            <div class="alert alert-warning">На выбранную дату нет прогноза. Нажмите «Сгенерировать прогноз», чтобы создать его.</div>
        <?php else: ?>
            <!-- Общая статистика -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-number"><?= number_format($total_visitors_day) ?></div>
                    <div class="stat-label">Всего посетителей за день</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?= array_sum(array_column($staff_requirements, 'trainers')) ?></div>
                    <div class="stat-label">Тренеро-часов</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?= array_sum(array_column($staff_requirements, 'admins')) ?></div>
                    <div class="stat-label">Админо-часов</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?= max(0, 20 - count($peak_hours)) ?></div>
                    <div class="stat-label">Непиковых часов</div>
                </div>
            </div>
            
            <!-- Пиковые часы -->
            <?php if (count($peak_hours) > 0): ?>
                <div class="alert alert-warning">
                    <strong>Пиковые часы:</strong> с <?= implode(':00, ', $peak_hours) ?>:00. В эти часы требуется максимальное количество персонала.
                </div>
            <?php endif; ?>
            
            <!-- Легенда -->
            <div class="legend">
                <strong>Уровень загрузки:</strong>
                <span><span class="legend__swatch legend__swatch--low"></span> До 30 чел</span>
                <span><span class="legend__swatch legend__swatch--medium"></span> 31-50 чел</span>
                <span><span class="legend__swatch legend__swatch--high"></span> 51-80 чел</span>
                <span><span class="legend__swatch legend__swatch--critical"></span> Более 80 чел</span>
            </div>
            
            <!-- Таблица прогноза и расчёта персонала -->
            <div class="table-wrap">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Время</th>
                            <th>Прогноз посещаемости</th>
                            <th>Уровень</th>
                            <th>Тренеры</th>
                            <th>Администраторы</th>
                            <th>Директор</th>
                            <th>Всего персонала</th>
                            <th>Статус</th>
                            <th>Действие</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $max_visitors = max(array_column($staff_requirements, 'visitors'));
                        foreach ($staff_requirements as $hour => $req):
                            $percent = round(($req['visitors'] / $max_visitors) * 100);
                            
                            // Определяем класс для цвета
                            if ($req['visitors'] <= 30) $row_class = 'row-low';
                            elseif ($req['visitors'] <= 50) $row_class = 'row-medium';
                            elseif ($req['visitors'] <= 80) $row_class = 'row-high';
                            else $row_class = 'row-critical';
                            
                            // Определяем статус загрузки
                            if ($req['visitors'] <= 30) $status = 'Низкая';
                            elseif ($req['visitors'] <= 50) $status = 'Средняя';
                            elseif ($req['visitors'] <= 80) $status = 'Высокая';
                            else $status = 'Критическая';
                            
                            // Проверяем, хватает ли персонала по факту
                            $actual_trainers = $actual_shifts[$hour]['trainer'] ?? 0;
                            $need_warning = $actual_trainers > 0 && $actual_trainers < $req['trainers'];
                        ?>
                            <tr class="<?= $row_class ?>">
                                <td><strong><?= sprintf("%02d:00 - %02d:00", $hour, $hour+1) ?></strong></td>
                                <td><strong><?= number_format($req['visitors']) ?></strong> чел.</td>
                                <td>
                                    <span class="progress"><span class="progress__bar" data-percent="<?= $percent ?>"></span></span>
                                    <span class="muted"><?= $percent ?>%</span>
                                </td>
                                <td><strong><?= $req['trainers'] ?></strong><?php if ($need_warning): ?> <span class="muted">(мало по факту)</span><?php endif; ?></td>
                                <td><strong><?= $req['admins'] ?></strong></td>
                                <td><?= $req['director'] ? 'Нужен' : 'Не нужен' ?></td>
                                <td><strong><?= $req['total_staff'] ?></strong></td>
                                <td><?= $status ?></td>
                                <td>
                                    <a href="auto_schedule.php?date=<?= $selected_date ?>&hour=<?= $hour ?>" class="btn btn-sm">Назначить смену</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <hr>
            
            <!-- Рекомендации -->
            <div class="alert alert-info">
                <strong>Рекомендации по загрузке персонала:</strong>
                <ul class="list">
                    <li>Пиковая нагрузка: <strong><?= max(array_column($staff_requirements, 'visitors')) ?> человек</strong> в час</li>
                    <li>Максимально нужно тренеров: <strong><?= max(array_column($staff_requirements, 'trainers')) ?></strong> в час</li>
                    <li>Максимально нужно администраторов: <strong><?= max(array_column($staff_requirements, 'admins')) ?></strong> в час</li>
                    <li>Самые загруженные часы: 
                        <?php 
                        $sorted = $staff_requirements;
                        uasort($sorted, function($a, $b) {
                            return $b['visitors'] <=> $a['visitors'];
                        });
                        $top3 = array_slice($sorted, 0, 3);
                        foreach ($top3 as $hour => $req):
                            echo "<strong>{$hour}:00</strong> ({$req['visitors']} чел.) ";
                        endforeach;
                        ?>
                    </li>
                </ul>
            </div>
            
            <!-- Кнопка быстрого создания расписания -->
            <div class="mt-16 text-center">
                <a href="auto_schedule.php?date=<?= $selected_date ?>" class="btn">
                    Создать автоматическое расписание на основе прогноза
                </a>
            </div>
        <?php endif; ?>
        
        <a href="dashboard.php" class="back-link">Вернуться на главную</a>
    </div>

    <script>
      document.querySelectorAll('.progress__bar[data-percent]').forEach(function (el) {
        var v = parseInt(el.getAttribute('data-percent') || '0', 10);
        if (!Number.isFinite(v)) v = 0;
        v = Math.max(0, Math.min(100, v));
        el.style.width = v + '%';
      });
    </script>
</body>
</html>